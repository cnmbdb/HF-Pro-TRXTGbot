#!/usr/bin/env bash

python3.10 check.py > check.log 2>&1 &
python3.10 bot.py > bot.log 2>&1 &


#!/usr/bin/python3
from pymysql import Connect, cursors

def conn_db():
    conn = Connect(
        host="localhost",
        port=3306,
        user="root",
        password='uujukupassword',
        db="bot_2500",
        cursorclass=cursors.DictCursor
    )
    return conn
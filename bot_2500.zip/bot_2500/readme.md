运行脚本:python3.10+

pip install tronpy

pip install pymysql

pip install requests

pip install python-telegram-bot==20.0a4


pip install APScheduler 

数据库:mysql5.7+

详细配置bot_config.py 注释有
